/**  
 * toggles the red cross display on or off using .hidden class
*/
function redCross() {
    let crossContainer = document.querySelector('.crossContainer');
    crossContainer.classList.toggle('hidden'); 
}