<?php

function gotPanels(){
    return !empty($_POST['panels']);
}