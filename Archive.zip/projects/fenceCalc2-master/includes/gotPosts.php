<?php

function gotPosts(){
    return !empty($_POST['posts']);
}