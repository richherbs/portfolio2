
<?php
function gotPostsAndPanels(){
            return !empty($_POST['panels']) && !empty($_POST['posts']);
        }